// src/utils/monthComparison.ts

export interface MonthComparisonResult {
    current: number
    previous: number
    difference: number
    percentageChange: number
    direction:
        | "increase"
        | "decrease"
        | "same"
}


// =====================================================
// COMPARE MONTHS
// =====================================================

export function compareMonths(
    current: number,
    previous: number
): MonthComparisonResult {

    const difference =
        current - previous

    // Previous month was zero
    if (previous === 0) {

        if (current === 0) {

            return {
                current,
                previous,
                difference: 0,
                percentageChange: 0,
                direction: "same",
            }
        }

        return {
            current,
            previous,
            difference,
            percentageChange: 100,
            direction:
                current > 0
                    ? "increase"
                    : "decrease",
        }
    }

    const percentageChange =
        (difference / Math.abs(previous)) * 100

    let direction:
        | "increase"
        | "decrease"
        | "same"

    if (difference > 0) {

        direction = "increase"

    } else if (difference < 0) {

        direction = "decrease"

    } else {

        direction = "same"
    }

    return {
        current,
        previous,
        difference,
        percentageChange,
        direction,
    }
}


// =====================================================
// BUILD MONTH COMPARISON
// =====================================================

export function buildMonthComparison(
    current: number,
    previous: number
): MonthComparisonResult {

    return compareMonths(
        Number(current) || 0,
        Number(previous) || 0
    )
}


// =====================================================
// FORMAT PERCENTAGE CHANGE
// =====================================================

export function formatPercentageChange(
    percentage: number
): string {

    const absolute =
        Math.abs(
            Number(percentage) || 0
        )

    if (absolute < 0.01) {
        return "0%"
    }

    return `${absolute.toFixed(1)}%`
}


// =====================================================
// GET COMPARISON ARROW
// =====================================================

export function getComparisonArrow(
    direction:
        | "increase"
        | "decrease"
        | "same"
): string {

    switch (direction) {

        case "increase":
            return "↑"

        case "decrease":
            return "↓"

        default:
            return "→"
    }
}