import { useQuery } from "@tanstack/react-query"

import {
    getAnalytics,
} from "@/services/analyticsApi"


export function useAnalytics(
    month: number,
    year: number
) {

    return useQuery({
        queryKey: [
            "analytics",
            month,
            year,
        ],

        queryFn: () =>
            getAnalytics(
                month,
                year
            ),

        enabled:
            Boolean(
                localStorage.getItem(
                    "token"
                )
            ),

        staleTime:
            30 * 1000,

        refetchOnWindowFocus:
            false,
    })
}