// =====================================================
// TYPES
// =====================================================

export interface FinancialHealth {
    score: number
    label: string
}


// =====================================================
// CALCULATE FINANCIAL HEALTH
// =====================================================

export function calculateFinancialHealth(
    savingsRate: number,
    expenseChange: number,
    budgetPercentage: number
): FinancialHealth {

    let score = 50


    // =====================================================
    // SAVINGS RATE
    // =====================================================

    if (savingsRate >= 30) {

        score += 25

    } else if (savingsRate >= 20) {

        score += 18

    } else if (savingsRate >= 10) {

        score += 10

    } else if (savingsRate < 0) {

        score -= 20
    }


    // =====================================================
    // EXPENSE TREND
    // =====================================================

    if (expenseChange < 0) {

        // Expenses decreased
        score += 10

    } else if (expenseChange > 20) {

        // Expenses increased significantly
        score -= 10
    }


    // =====================================================
    // BUDGET UTILIZATION
    // =====================================================

    if (budgetPercentage <= 70) {

        score += 15

    } else if (budgetPercentage <= 85) {

        score += 8

    } else if (budgetPercentage >= 100) {

        score -= 20
    }


    // =====================================================
    // CLAMP SCORE
    // =====================================================

    score = Math.max(
        0,
        Math.min(
            100,
            score
        )
    )


    // =====================================================
    // HEALTH LABEL
    // =====================================================

    let label =
        "Needs attention"


    if (score >= 85) {

        label =
            "Excellent"

    } else if (score >= 70) {

        label =
            "Healthy"

    } else if (score >= 50) {

        label =
            "Fair"
    }


    return {
        score,
        label,
    }
}